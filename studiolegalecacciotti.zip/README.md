# studiolegalecacciotti

The One-Page Animated Website is a responsive and user-friendly interface built with HTML, CSS, and JavaScript (GSAP library). It features captivating animations, adaptivity across devices, and a seamless browsing experience.

## Features
Single-page design for smooth navigation
Interactive animations using GSAP library
Responsive layout for different screen sizes
